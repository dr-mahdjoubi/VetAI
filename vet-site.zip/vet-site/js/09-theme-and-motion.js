/* 09-theme-and-motion */
(function(){const b=document.body;let t=null,m='0';try{t=localStorage.getItem('theme');m=localStorage.getItem('mv')||'0'}catch(e){}
if(!t)t=(window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches)?'light':'calm';
function ap(x){t=x;b.dataset.theme=x;try{localStorage.setItem('theme',x)}catch(e){}document.querySelectorAll('#thm [data-t]').forEach(e=>{e.classList.toggle('bg-vetCyan',e.dataset.t==x);e.classList.toggle('text-slate-900',e.dataset.t==x)})}
document.getElementById('thm').onclick=e=>{const k=e.target.closest('[data-t]');if(k)ap(k.dataset.t)};
const c=document.getElementById('mvt');c.checked=m=='1';b.dataset.mv=m;c.onchange=()=>{b.dataset.mv=c.checked?'1':'0';try{localStorage.setItem('mv',b.dataset.mv)}catch(e){}};ap(t)})();
