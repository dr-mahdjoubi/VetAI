/* 20-university-cards */
/* بطاقات الجامعات الثلاث: حجم مصغّر + النقر يفتح الموقع الرسمي في تبويب جديد */
(function(){
  var U=[
    {k:/RVC|الملكية/,url:'https://www.rvc.ac.uk',t:'Royal Vet College',c:'#06b6d4'},
    {k:/كورنيل/,url:'https://www.vet.cornell.edu',t:'Cornell University',c:'#8b5cf6'},
    {k:/سيدني/,url:'https://sydney.edu.au/vetscience/',t:'University of Sydney',c:'#10b981'}
  ];
  function banner(t,c){
    var s='<svg xmlns="http://www.w3.org/2000/svg" width="600" height="150"><rect width="100%" height="100%" fill="#0f172a"/><text x="50%" y="50%" fill="'+c+'" font-family="sans-serif" font-size="46" font-weight="700" text-anchor="middle" dominant-baseline="middle">'+t+'</text></svg>';
    return 'data:image/svg+xml;base64,'+btoa(s);
  }
  function go(url){var w=window.open(url,'_blank','noopener,noreferrer');if(!w)location.href=url;}
  function apply(){
    var grid=document.querySelector('#uni-end>.grid');
    if(!grid||grid.dataset.uniMini)return;
    grid.dataset.uniMini='1';
    Array.prototype.forEach.call(grid.children,function(card){
      var h=card.querySelector('h3');if(!h)return;
      var u=U.filter(function(x){return x.k.test(h.textContent);})[0];
      if(!u)return;
      card.classList.add('uni-mini');
      card.setAttribute('role','link');card.setAttribute('tabindex','0');
      card.setAttribute('aria-label',h.textContent.trim()+' — فتح الموقع الرسمي');
      card.title='فتح الموقع الرسمي';
      var img=card.querySelector('img');if(img){img.src=banner(u.t,u.c);img.alt=u.t;}
      var btn=card.querySelector('button');
      if(btn){btn.removeAttribute('onclick');btn.textContent='زيارة الموقع ↗';}
      card.addEventListener('click',function(){go(u.url);});
      card.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go(u.url);}});
    });
    if(!document.getElementById('uni-mini-css')){
      var s=document.createElement('style');s.id='uni-mini-css';
      s.textContent='#uni-end>.grid{gap:12px!important}'+
        '#uni-end .uni-mini{cursor:pointer;transition:transform .15s ease}'+
        '#uni-end .uni-mini:hover{transform:translateY(-2px)}#uni-end .uni-mini:active{transform:scale(.98)}'+
        '#uni-end .uni-mini>div:first-child{height:84px!important}'+
        '#uni-end .uni-mini img{height:84px!important;width:100%!important;object-fit:cover}'+
        '#uni-end .uni-mini>div:last-child{padding:12px!important}'+
        '#uni-end .uni-mini h3{font-size:.9rem!important;line-height:1.35}'+
        '#uni-end .uni-mini p{font-size:.72rem!important;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'+
        '#uni-end .uni-mini>div:last-child>div{padding-top:8px!important}'+
        '@media(prefers-reduced-motion:reduce){#uni-end .uni-mini{transition:none}}';
      document.head.appendChild(s);
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
  window.addEventListener('load',apply);
})();
