/* 11-navigation-groups */
(function(){const g=id=>document.getElementById(id);
const G=[['home','🏠 الرئيسية',[['home','الرئيسية']]],['ref','📖 مرجع',[['ref','المرجع السريري'],['drugs','الأدوية والعلاجات'],['dxlab','الأمراض والتحاليل'],['catalog','موسوعة المواضيع'],['knowledge','الموسوعة والعلوم']]],['tools','🛠️ أدوات',[['ai-diagnostics','مُقيِّم الأعراض الذكي'],['services','الخدمات']]],['learn','🎓 تعلّم',[['exams','الدروس والاختبارات'],['library','المكتبة والكتب'],['uni','الجامعات ↓']]],['comm','💬 مجتمع',[['chat','المجتمع وبيطري-AI']]],['about','ℹ️ عنّا',[['about','عن المنصة'],['creator','المؤسس والتواصل'],['legal','الخصوصية والشروط']]],['fun','🎮 ألعاب',[['fun','ألعاب الحيوانات']]]];
const on='bg-vetCyan text-slate-900',off='bg-slate-900 border border-slate-700 text-slate-300';
const bc='px-3 py-2 rounded-xl text-xs font-bold ';
let cg='home',ct='home';
function paint(){g('gtop').innerHTML=G.map(x=>'<button data-g="'+x[0]+'" class="'+bc+(x[0]==cg?on:off)+'">'+x[1]+'</button>').join('');const grp=G.find(x=>x[0]==cg),s=g('gsub');if(grp[2].length>1){s.classList.remove('hidden');s.innerHTML=grp[2].map(t=>'<button data-t="'+t[0]+'" class="px-3 py-1.5 rounded-lg text-[11px] font-bold '+(t[0]==ct?'bg-slate-700 text-white':'text-slate-300 hover:bg-slate-800')+'">'+t[1]+'</button>').join('')}else{s.classList.add('hidden');s.innerHTML=''}}
const orig=window.switchTab;
window.switchTab=function(t){orig(t);ct=t;const f=G.find(x=>x[2].some(y=>y[0]==t));if(f)cg=f[0];paint()};
g('gnav').onclick=e=>{const a=e.target.closest('[data-g]');if(a){const grp=G.find(x=>x[0]==a.dataset.g);cg=grp[0];const f=grp[2][0][0];f=='uni'?paint():switchTab(f);return}const b=e.target.closest('[data-t]');if(b){b.dataset.t=='uni'?document.getElementById('uni-end').scrollIntoView({behavior:'smooth'}):switchTab(b.dataset.t)}};
paint();
// about form
const m=()=>encodeURIComponent('رسالة من الموقع\nالاسم: '+g('cfn').value+'\nللتواصل: '+g('cfe').value+'\n'+g('cfm').value);
g('cfw').onclick=()=>window.open('https://wa.me/213540661865?text='+m(),'_blank');g('cfb').onclick=()=>window.open('mailto:dr.mahdjoubi@gmail.com?subject='+encodeURIComponent('رسالة من منصة د. محجوبي')+'&body='+m());
document.querySelectorAll('.rev').forEach(b=>b.onclick=()=>window.open('https://wa.me/213540661865?text='+encodeURIComponent(b.dataset.m),'_blank'));
// local diseases
const R=window.__refR||[];g('homeLocal').innerHTML=['البروسيلا','الليشمانيا الكلبية','الحمى القلاعية','الجلد العقدي','السعار','التهاب الضرع'].map(t=>{const i=R.findIndex(r=>r[0]==t);return i<0?'':'<button data-a="'+i+'" class="text-right rounded-2xl glass-panel p-4 hover:border-vetCyan transition"><div class="font-black text-sm">'+R[i][0]+'</div><p class="text-xs text-slate-300 mt-1 leading-relaxed">'+R[i][8]+'</p></button>'}).join('');
g('homeLocal').onclick=e=>{const b=e.target.closest('[data-a]');if(b){switchTab('ref');window.__ref&&window.__ref('a:'+b.dataset.a)}};
// feedback
g('fbk').onclick=e=>{const b=e.target.closest('[data-f]');if(!b)return;let c={up:0,down:0};try{c=JSON.parse(localStorage.getItem('fbk')||'{"up":0,"down":0}')}catch(x){}c[b.dataset.f]++;try{localStorage.setItem('fbk',JSON.stringify(c))}catch(x){}
const us=document.querySelectorAll('#msgs .m.u'),lq=us.length?us[us.length-1].textContent:'';
g('fbm').innerHTML=b.dataset.f=='up'?'شكرًا لتقييمك 🌿':'نأسف. <a class="text-sky-300 underline" target="_blank" rel="noopener" href="https://wa.me/213540661865?text='+encodeURIComponent('إجابة غير مفيدة من المساعد. سؤالي: '+lq)+'">أبلغ الدكتور بالسؤال</a>'};
})();
