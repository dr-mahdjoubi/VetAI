/* config */
// ضع هنا رابط الوسيط (Cloudflare Worker) ليصبح البحث الشامل على الويب بـ Gemini المجاني. اتركه فارغًا لتعطيله.
    window.VET_AI_ENDPOINT = "/api/vet-ai";
    // (اختياري) معرّف محرك بحث غوغل المبرمج (cx) لعرض نتائج غوغل نفسها داخل الصفحة: programmablesearchengine.google.com
    window.VET_CSE_ID = "";
