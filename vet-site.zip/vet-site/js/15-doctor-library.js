/* 15-doctor-library */
(function(){
  function ok(u){return typeof u==='string'&&/^(\/|\.\/|[\w-]+\/|https:\/\/)/.test(u)&&!/^\s*javascript:/i.test(u);}
  async function load(p){try{var r=await fetch(p,{cache:'no-store'});return r.ok?await r.json():{};}catch(e){return {};}}
  function head(t){var h=document.createElement('h4');h.textContent=t;h.style.cssText='margin:14px 0 6px;font-weight:800';return h;}
  function link(box,x){
    if(!ok(x.file))return false;
    var a=document.createElement('a');a.className='bk';a.href=x.file;a.target='_blank';a.rel='noopener';
    a.textContent='📘 '+(x.title||'')+(x.author?' — '+x.author:'')+(x.subject?' ('+x.subject+')':'')+(x.year?' '+x.year:'');
    box.appendChild(a);return true;
  }
  async function run(){
    var any=false;
    var b=(await load('data/books.json')).books||[];
    var bb=document.getElementById('myBooks');
    if(b.length){bb.appendChild(head('📚 الكتب'));b.forEach(function(x){if(link(bb,x))any=true;});}
    var ar=(await load('data/articles.json')).articles||[];
    var ab=document.getElementById('myArticles');
    if(ar.length){
      ab.appendChild(head('📝 المقالات'));
      ar.forEach(function(x){
        var d=document.createElement('details');d.className='art';
        var s=document.createElement('summary');s.textContent=(x.title||'')+(x.date?' · '+String(x.date).slice(0,10):'');d.appendChild(s);
        if(x.summary){var p=document.createElement('p');p.className='muted';p.textContent=x.summary;d.appendChild(p);}
        String(x.body||'').split(/\n{2,}/).forEach(function(t){if(t.trim()){var p=document.createElement('p');p.textContent=t.trim();p.style.margin='6px 0';d.appendChild(p);}});
        if(x.image&&ok(x.image)){var i=document.createElement('img');i.src=x.image;i.alt='';i.loading='lazy';i.style.cssText='max-width:100%;border-radius:10px;margin-top:6px';d.appendChild(i);}
        ab.appendChild(d);any=true;
      });
    }
    var ex=(await load('data/exams.json')).exams||[];
    var eb=document.getElementById('myExams');
    if(ex.length){eb.appendChild(head('📝 الامتحانات'));ex.forEach(function(x){if(link(eb,x))any=true;});}
    var g=(await load('data/gallery.json')).photos||[];
    var gb=document.getElementById('myGallery');
    g.forEach(function(x){
      if(!ok(x.image))return;
      var i=document.createElement('img');i.src=x.image;i.alt=x.caption||'';i.loading='lazy';
      i.style.cssText='width:100%;height:110px;object-fit:cover;border-radius:8px';gb.appendChild(i);any=true;
    });
    if(any){var e=document.getElementById('myLibEmpty');if(e)e.remove();}
  }
  run();
})();
