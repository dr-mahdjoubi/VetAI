/* 22-accessibility-offline */
/* تحسينات الإتاحة والأداء وعدم الاتصال — دون تغيير التصميم */
(function(){
  function fix(){
    // 1) نصوص بديلة وتحميل كسول للصور
    Array.prototype.forEach.call(document.images,function(img){
      if(!img.hasAttribute('alt'))img.setAttribute('alt','');
      if(!img.hasAttribute('loading')&&!img.closest('header'))img.setAttribute('loading','lazy');
      if(!img.hasAttribute('decoding'))img.setAttribute('decoding','async');
    });
    // 2) أرقام بحثية بلا مصدر في بطاقات الجامعات
    Array.prototype.forEach.call(document.querySelectorAll('#uni-end span'),function(s){
      if(/الأبحاث المعتمدة:\s*\d+\s*ورقة/.test(s.textContent))s.remove();
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fix);else fix();
  window.addEventListener('load',fix);

  // 3) احترام «تقليل الحركة» في إعدادات الجهاز (الحيوانات الطائرة وشريط الأخبار)
  var st=document.createElement('style');
  st.textContent='@media (prefers-reduced-motion:reduce){#fl span,#tkt,.bsm *{animation:none!important}}';
  document.head.appendChild(st);

  // 4) تثبيت كتطبيق + عمل المرجع دون إنترنت
  try{
    var l=document.createElement('link');l.rel='manifest';l.href='manifest.json';document.head.appendChild(l);
    var a=document.createElement('link');a.rel='apple-touch-icon';a.href='icon-192.png';document.head.appendChild(a);
    if(!document.querySelector('meta[name="theme-color"]')){var t=document.createElement('meta');t.name='theme-color';t.content='#10b981';document.head.appendChild(t);}
    if('serviceWorker' in navigator&&(location.protocol==='https:'||location.hostname==='localhost')){
      window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});
    }
  }catch(e){}
})();
