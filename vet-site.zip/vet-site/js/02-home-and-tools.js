/* 02-home-and-tools */
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function tick(){const n=new Date();$('#clock').textContent=n.toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit'})+' · '+n.toLocaleDateString('ar-DZ',{weekday:'long',day:'numeric',month:'long'});}
setInterval(tick,1000);tick();

const knowledgeInput=$('#knowledgeSearch');
function filterKnowledge(cat='all'){
 const q=knowledgeInput.value.trim().toLowerCase();
 $$('.know').forEach(c=>c.style.display=((cat==='all'||c.dataset.cat===cat)&&(!q||c.dataset.text.toLowerCase().includes(q)||c.textContent.toLowerCase().includes(q)))?'block':'none');
}
knowledgeInput.addEventListener('input',()=>filterKnowledge(window.kcat||'all'));
$('#clearSearch').onclick=()=>{knowledgeInput.value='';window.kcat='all';filterKnowledge();};
$$('[data-filter]').forEach(b=>b.onclick=()=>{window.kcat=b.dataset.filter;filterKnowledge(window.kcat);});

$('#calcDose').onclick=()=>{const w=parseFloat($('#weight').value),d=parseFloat($('#dose').value);$('#doseResult').textContent=(w>0&&d>=0)?`الناتج الحسابي = ${(w*d).toFixed(2)} mg\nهذا حساب رياضي فقط وليس توصية بجرعة.`:'أدخل الوزن والقيمة بشكل صحيح.'};
$('#calcAge').onclick=()=>{const b=$('#birth').value;if(!b){$('#ageResult').textContent='اختر تاريخ الميلاد.';return}const bd=new Date(b),now=new Date();let y=now.getFullYear()-bd.getFullYear(),m=now.getMonth()-bd.getMonth();if(m<0){y--;m+=12}if(now.getDate()<bd.getDate())m=Math.max(0,m-1);$('#ageResult').textContent=`العمر التقريبي: ${Math.max(0,y)} سنة و${Math.max(0,m)} شهر.`};
function webOpen(base){const q=$('#webq').value.trim();if(q)window.open(base+encodeURIComponent(q),'_blank','noopener');}
$('#googleBtn').onclick=()=>webOpen('https://www.google.com/search?q=');
$('#youtubeBtn').onclick=()=>webOpen('https://www.youtube.com/results?search_query=');
$('#aiDemo').onclick=()=>{const q=$('#aiq').value.trim();$('#aiResult').textContent=q?`تصنيف أولي للسؤال: ${q.includes('مرض')||q.includes('أعراض')?'أعراض/مرض':q.includes('دواء')||q.includes('جرعة')?'دواء — يحتاج مراجعة طبيب بيطري':q.includes('بحث')||q.includes('دراسة')?'بحث علمي':'استفسار بيطري عام'}\n\nيمكن ربط هذه الواجهة لاحقًا بنموذج ذكاء اصطناعي وقاعدة مصادر موثوقة.`:'اكتب سؤالًا أولًا.'};

const quiz=[
['أي حيوان يُعد من المجترات؟',['الأبقار','القطط','الدجاج'],'الأبقار'],
['ما الغذاء الذي قد يكون سامًا للكلاب؟',['الشوكولاتة','الجزر','الأرز'],'الشوكولاتة'],
['أي حيوان من الطيور؟',['الحصان','الدجاج','الأغنام'],'الدجاج'],
['ما الإجراء الأساسي عند الاشتباه بمرض معدٍ في قطيع؟',['العزل والتقييم البيطري','زيادة الازدحام','إيقاف الماء'],'العزل والتقييم البيطري']
];let qi=0,score=0;
function renderQuiz(){const x=quiz[qi];$('#quizQ').textContent=x[0];$('#quizOpts').innerHTML=x[1].map(o=>`<button class="btn alt quizOpt">${o}</button>`).join('');$$('.quizOpt').forEach(b=>b.onclick=()=>{if(b.textContent===x[2])score++;qi=(qi+1)%quiz.length;$('#quizScore').textContent='النقاط: '+score;renderQuiz();});}renderQuiz();

const animals=['🐕','🐈','🐄','🐑','🐓','🐎','🐇','🐪'];let first=null,lock=false;
function newMemory(){const a=[...animals.slice(0,4),...animals.slice(0,4)].sort(()=>Math.random()-.5);$('#memory').innerHTML=a.map((x,i)=>`<button class="tile" data-v="${x}" data-i="${i}">❓</button>`).join('');first=null;lock=false;$$('.tile').forEach(t=>t.onclick=()=>{if(lock||t.classList.contains('done')||t===first)return;t.textContent=t.dataset.v;if(!first){first=t;return}if(first.dataset.v===t.dataset.v){first.classList.add('done');t.classList.add('done');first=null}else{lock=true;setTimeout(()=>{first.textContent='❓';t.textContent='❓';first=null;lock=false},650)}})}newMemory();$('#resetMemory').onclick=newMemory;

const riddles=[['أعيش غالبًا في المزرعة وأنتج الحليب.','🐄 البقرة'],['أحب الجزر في الرسوم المتحركة وأقفز كثيرًا.','🐇 الأرنب'],['أُعرف بالوفاء وأستطيع حراسة المنزل.','🐕 الكلب'],['أطير ولدي ريش وأضع البيض.','🐓 الدجاجة']];
let ri=0;function showR(){const x=riddles[ri];$('#whoHint').textContent=x[0];$('#whoResult').textContent='؟'}showR();$('#whoAnswer').onclick=()=>$('#whoResult').textContent=riddles[ri][1];$('#whoNext').onclick=()=>{ri=(ri+1)%riddles.length;showR()};

$('#sendWA').onclick=()=>{const n=$('#cn').value.trim(),p=$('#cph').value.trim(),a=$('#ca').value.trim();const m=`السلام عليكم دكتور، أنا ${n}.\nهاتف: ${p}\nالاستشارة: ${a}`;window.open('https://wa.me/213540661865?text='+encodeURIComponent(m),'_blank','noopener')};




const K=[
[["💉 برنامج التلقيح","تبدأ لقاحات الجراء والقطط الصغيرة غالبًا بين 6 و8 أسابيع وتتكرر بجرعات منشّطة وفق برنامج الطبيب. للكلاب: السعار والبارفو والبرد الكلبي. للقطط: الرعام وكاليسي والبانلوكوبينيا والسعار."],["🪱 الطفيليات","البراغيث والقراد والديدان الداخلية تُكافَح بانتظام. يحدد الطبيب المنتج المناسب حسب النوع والعمر والوزن، ولا تُستخدم منتجات الكلاب على القطط."],["🚑 الإسعاف الأولي","أوقف النزيف بالضغط المباشر، ولا تعطِ أدوية بشرية، وبرّد الحرارة المرتفعة تدريجيًا بالماء الفاتر، ثم توجه فورًا للعيادة."]],
[["🦠 الحمى القلاعية","مرض فيروسي شديد العدوى: حمى وتقرحات في الفم والظلف وسيلان لعاب وعرج وانخفاض الحليب. يُبلَّغ عنه السلطات البيطرية وتُعزل الحيوانات ويُمنع نقلها."],["🥛 التهاب الضرع","الوقاية: حلب نظيف، غمس الحلمات بعد الحلب، صيانة آلة الحلب، واختبار الحليب دوريًا. العلاج يكون بإشراف الطبيب لتجنب المقاومة ومتبقيات المضادات في الحليب."],["🐑 التناسل والتغذية","راقب الشبق وحالة الجسم، وقدّم غذاءً متوازنًا قبل الولادة، وأعطِ المولود السَّرسوب (اللبأ) خلال الساعات الأولى لحمايته من الأمراض."]],
[["🛡️ الأمن الحيوي","قيّد دخول الزوار، وفرّ مطهرات عند المداخل، وافصل الأعمار، ونظّف وعقّم العنابر بين الدفعات، وتخلص من النافق بطريقة آمنة."],["💉 التحصين","تشمل البرامج عادةً النيوكاسل والجمبورو والتهاب القصبات المعدي، ويُضبط الجدول حسب المنطقة والمخاطر بإشراف الطبيب."],["🌡️ الحرارة والتهوية","تحتاج الصيصان نحو 32–33°م في الأسبوع الأول ثم تنخفض تدريجيًا نحو 3°م أسبوعيًا. التهوية الجيدة تقلل الأمونيا والرطوبة وأمراض الجهاز التنفسي."]],
[["🍫 الشوكولاتة والكافيين","تحتوي الثيوبرومين السام للكلاب والقطط، والداكنة أخطر. من الأعراض: قيء وعطش ورعشة وتسارع القلب. اتصل بالطبيب فورًا."],["🧅 البصل والثوم","قد يسببان فقر دم انحلاليًا، والقطط أكثر حساسية. الخطر قائم حتى في الأطعمة المطبوخة أو المسحوق."],["🍇 العنب والزبيب والزيليتول","العنب والزبيب قد يسببان فشلًا كلويًا في الكلاب، والزيليتول (محلٍّ صناعي) يسبب هبوط السكر وتلف الكبد. لا تُحفّز القيء دون توجيه الطبيب."]],
[["🤖 الذكاء الاصطناعي","يُستخدم في قراءة صور الأشعة والمسحات المجهرية والتنبؤ بالأمراض في القطعان، ويدعم الطبيب ولا يحل محله."],["💊 اللقاحات ومقاومة المضادات","تتطور لقاحات مؤتلفة أكثر أمانًا. الاستخدام الرشيد للمضادات الحيوية ضروري للحد من المقاومة التي تهدد صحة الإنسان والحيوان."],["📡 الزراعة الدقيقة","أطواق ومستشعرات ذكية ترصد نشاط الأبقار وحرارتها ورعايتها، فتكشف الشبق والمرض مبكرًا، مع دعم الجينوميات في الانتخاب."]],
[["📘 مصطلحات أساسية","Anamnesis: التاريخ المرضي. Auscultation: الإصغاء. Pathognomonic: علامة مميزة لمرض بعينه. Zoonosis: مرض مشترك. Prophylaxis: وقاية."],["❓ أسئلة مراجعة","ما الفرق بين المجترات وأحادية المعدة؟ ما أقسام معدة البقرة؟ لماذا تُعطى الصغار اللبأ مبكرًا؟ ما الفرق بين المرض الحاد والمزمن؟"],["🧫 الأمراض المشتركة","السعار والبروسيلا والكيس العدري والليشمانيا أمراض مشتركة مهمة. تعتمد الوقاية على التلقيح والنظافة وتجنب الحليب غير المبستر ومراقبة الكلاب السائبة."]]
];
$$('.know').forEach((c,i)=>{const h=c.querySelector('h3').outerHTML,p=c.querySelector('p').outerHTML;c.innerHTML='<details>'+'<summary>'+h+p+'</summary>'+K[i].map(a=>'<details class="art"><summary>'+a[0]+'</summary><p class="muted">'+a[1]+'</p></details>').join('')+'</details>';});


const X=[[["🐾 العناية اليومية","افحص الأسنان والأذن والجلد أسبوعيًا، وقدّم ماءً نظيفًا وتمارين مناسبة، وراقب الوزن شهريًا."]],[["🌿 إدارة المرعى","تناوب الرعي يقلل الطفيليات الداخلية ويحسّن جودة العشب، ووفّر الماء والأملاح المعدنية دائمًا."]],[["🥚 الإنتاج والتغذية","توازن البروتين والطاقة والكالسيوم أساس نمو الصيصان وإنتاج البيض، ويُراقب الاستهلاك اليومي للعلف والماء كمؤشر مبكر للمرض."]],[["🌱 نباتات سامة","الزنبق خطير على القطط، والأوليندر والكسافا سامة للحيوانات. أبعدها عن المتناول واسأل الطبيب عند الشك."]],[["🧬 الصحة الواحدة","نهج One Health يربط صحة الإنسان والحيوان والبيئة لمواجهة الأمراض المشتركة ومقاومة المضادات."]],[["🧠 طرق المذاكرة","استخدم البطاقات والتكرار المتباعد وحالات سريرية قصيرة وارسم مخططات الأجهزة لتثبيت المعلومة."]]];
$$('.know').forEach((c,i)=>c.querySelector('details').insertAdjacentHTML('beforeend',X[i].map(a=>'<details class="art"><summary>'+a[0]+'</summary><p class="muted">'+a[1]+'</p></details>').join('')));
const R=[["🧫 مقاومة المضادات الحيوية","الاستخدام المفرط للمضادات في الثروة الحيوانية يسرّع ظهور سلالات مقاومة قد تنتقل للإنسان. الحل: استخدام رشيد بوصفة، تحسين الأمن الحيوي والتلقيح."],["🐄 البروسيلا في المجترات","مرض مشترك يسبب الإجهاض ويصيب الإنسان بالحمى المالطية. تقوم المكافحة على الفحص الدوري والتلقيح وعزل المصابين وبسترة الحليب."],["🐕 القضاء على السعار","تشير منظمة الصحة العالمية إلى أن تلقيح نحو 70٪ من الكلاب يقطع انتقال السعار، مع التوعية بعد العضّ والعلاج الوقائي للإنسان."],["🖥️ الذكاء الاصطناعي في التشخيص","تساعد الخوارزميات في قراءة الأشعة والتحاليل، لكن نتائجها تحتاج مراجعة بيطرية وبيانات تدريب متنوعة لتجنب التحيز."]];
$('#resArts').innerHTML=R.map(a=>'<details class="art"><summary>'+a[0]+'</summary><p class="muted">'+a[1]+'</p></details>').join('');
$('#spSel').onchange=e=>$('#spRes').textContent=e.target.value||'—';
const SY='أنت مساعد بيطري تعليمي باللغة العربية على موقع الدكتور محجوبي عبدالناصر. أجب بإيجاز ووضوح، ولا تعطِ جرعات علاجية محددة، وانصح بزيارة الطبيب في الحالات الخطيرة أو الطارئة.';
function add(t,c){const d=document.createElement('div');d.className='m '+c;d.textContent=t;$('#msgs').append(d);d.scrollIntoView({block:'nearest'});return d}
function local(q){const w=q.split(/\s+/).filter(x=>x.length>2);let best=null,s=0;$$('.art').forEach(a=>{const t=a.textContent;const n=w.filter(x=>t.includes(x)).length;if(n>s){s=n;best=t}});return best?best+'\n\n(من قاعدة معرفة الموقع)':'تعذّر الوصول للمساعد الذكي الآن (قد تحتاج الموافقة على تفعيله عند أول سؤال). يمكنك البحث عن سؤالك هنا: https://www.google.com/search?q='+encodeURIComponent(q)}
async function ask(q){add(q,'u');const b=add('…','b');let sm=null;try{sm=window.claude&&await claude.use('sample')}catch(e){}
if(sm){try{const r=await sm([{role:'user',content:SY+'\nالسؤال: '+q}],{cache:false,onText:({text})=>{b.textContent=text}});b.textContent=r.text;return}catch(e){}}
b.textContent=local(q)}
function go(){const q=$('#cq').value.trim();if(!q)return;$('#cq').value='';ask(q)}
$('#cs').onclick=go;$('#cq').onkeydown=e=>{if(e.key==='Enter')go()};
['ما أعراض السعار؟','متى أطعّم الجرو؟','كيف أمنع التهاب الضرع؟','ما الأطعمة السامة للكلاب؟'].forEach(t=>{const b=document.createElement('button');b.className='chip';b.textContent=t;b.onclick=()=>ask(t);$('#sugg').append(b)});


const D=new Date(),N=Math.floor((D-new Date(D.getFullYear(),0,0))/864e5);
const TIPS=window.VET_CONTENT.tips;
const TOP=window.VET_CONTENT.topics;
$('#dt').textContent='محتوى يتغير يوميًا · '+D.toLocaleDateString('ar-DZ',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
$('#tip').textContent=TIPS[N%TIPS.length];$('#topic').textContent=TOP[N%TOP.length];
$('#askTopic').onclick=()=>{switchTab('chat');ask('اشرح باختصار: '+$('#topic').textContent)};
const TK=window.VET_CONTENT.ticker;
const r=N%TK.length,t=TK.slice(r).concat(TK.slice(0,r));
$('#tkt').innerHTML=t.concat(t).map(a=>'<a class="mx-6" '+(a[1][0]=='#'?'data-go="'+a[1]+'" href="#"':'target="_blank" rel="noopener" href="'+a[1]+'"')+'>• '+a[0]+'</a>').join('');
const U=location.href,tx=encodeURIComponent('منصة د. محجوبي البيطرية'),uu=encodeURIComponent(U);
$('#sh').innerHTML=[['WhatsApp','https://wa.me/?text='+tx+'%20'+uu],['Messenger','fb-messenger://share/?link='+uu],['Facebook','https://www.facebook.com/sharer/sharer.php?u='+uu],['Telegram','https://t.me/share/url?url='+uu+'&text='+tx],['X','https://twitter.com/intent/tweet?text='+tx+'&url='+uu]].map(a=>'<a class="btn alt" target="_blank" rel="noopener" href="'+a[1]+'">'+a[0]+'</a>').join('')+'<button class="btn primary" id="cp">نسخ الرابط</button>';
$('#cp').onclick=async()=>{try{if(navigator.share)await navigator.share({title:'منصة د. محجوبي',url:U});else{await navigator.clipboard.writeText(U);$('#cp').textContent='تم النسخ ✓'}}catch(e){$('#cp').textContent=U}};
$('#tgo').onclick=async()=>{const s=$('#tsy').value.trim(),o=$('#tres');if(!s){o.textContent='صف الأعراض أولًا.';return}
if(/نزيف|تشنج|اختناق|انتفاخ|تنفس|سم|حادث|إغماء|لا يتبول|عسر ولادة/.test(s)){o.textContent='🔴 مؤشر طارئ: توجّه لأقرب عيادة بيطرية فورًا أو اتصل بالدكتور.';return}
o.textContent='⏳ جارٍ التقييم...';let m=null;try{m=window.claude&&await claude.use('sample')}catch(e){}
if(m){try{const x=await m('أنت مساعد فرز بيطري تعليمي. النوع: '+$('#tsp').value+'. الأعراض: '+s+'. أعطِ بالعربية بإيجاز: درجة الاستعجال (طارئ/خلال 24 ساعة/مراقبة)، سببان محتملان، ونصائح آمنة بلا جرعات.',{cache:false});o.textContent=x.text;return}catch(e){}}
o.textContent='🟡 راقب الحالة وتواصل مع الطبيب خلال 24 ساعة إذا استمرت الأعراض أو ساءت.'};
$('#vgo').onclick=()=>{const b=$('#vbd').value;if(!b){$('#vres').textContent='اختر تاريخ الميلاد.';return}$('#vres').textContent=$('#vsp').value.split(',').map(w=>{const d=new Date(b);d.setDate(d.getDate()+w*7);return 'الأسبوع '+w+': '+d.toLocaleDateString('ar-DZ',{day:'numeric',month:'long',year:'numeric'})}).join('\n')+'\nثم منشّط سنوي وفق الطبيب.'};
$('#wgo').onclick=()=>{const k=+$('#wkg').value;$('#wres').textContent=k>0?'≈ '+(k*$('#wsp').value/1000).toFixed(1)+' لتر/يوم':'أدخل الوزن.'};
const G=[['🇩🇿 المدرسة الوطنية العليا للبيطرة — الجزائر','https://www.google.com/search?q=المدرسة+الوطنية+العليا+للبيطرة+الجزائر'],['🇩🇿 معهد العلوم البيطرية — جامعة البليدة 1','https://www.google.com/search?q=معهد+العلوم+البيطرية+جامعة+البليدة'],['🇩🇿 المعهد البيطري — جامعة تيارت','https://www.google.com/search?q=معهد+علوم+بيطرية+جامعة+تيارت'],['🇩🇿 الطب البيطري — جامعة قسنطينة 1','https://www.google.com/search?q=علوم+بيطرية+جامعة+قسنطينة+1'],['🇬🇧 Royal Veterinary College','https://www.rvc.ac.uk'],['🇺🇸 UC Davis Veterinary Medicine','https://vetmed.ucdavis.edu'],['🇺🇸 Cornell Veterinary College','https://www.vet.cornell.edu'],['🇫🇷 ENV Alfort','https://www.vet-alfort.fr'],['🇫🇷 ENV Toulouse','https://www.envt.fr'],['🇧🇪 Ghent University — Vet Medicine','https://www.ugent.be'],['🇳🇱 Utrecht University','https://www.uu.nl']];
$('#ug').innerHTML=G.map(a=>'<a class="card" target="_blank" rel="noopener" href="'+a[1]+'"><div class="pic">🎓</div><h3>'+a[0]+'</h3><p class="small">فتح الموقع ↗</p></a>').join('');


const mn=$('main');
const AD=[['🧬 التحرير الجيني (CRISPR)','تُستخدم تقنيات التحرير الجيني بحثيًا لتحسين مقاومة الأمراض في الماشية والدواجن، مع نقاش أخلاقي وتشريعي واسع حول سلامتها وقبولها.'],['💉 لقاحات mRNA والمؤتلفة','منصات اللقاحات الحديثة تُسرّع تطوير لقاحات للأمراض الحيوانية الناشئة وتتيح التمييز بين الحيوان الملقّح والمصاب (استراتيجية DIVA).'],['📡 الطب البيطري عن بُعد','الاستشارات المرئية والمتابعة عبر الهاتف تقلل التنقل وتُسرّع فرز الحالات، خصوصًا في المناطق الريفية، لكنها لا تغني عن الفحص السريري.'],['🦠 الميكروبيوم المعوي','دراسة بكتيريا الأمعاء تفتح الباب لمعززات حيوية تحسّن الهضم والمناعة وتقلل الحاجة للمضادات الحيوية في المزارع.'],['🐎 الطب التجديدي','الخلايا الجذعية والبلازما الغنية بالصفائح تُستعمل في إصابات الأوتار والمفاصل عند الخيول والكلاب ضمن بروتوكولات يقررها المختص.'],['🛰️ المراقبة الوبائية','الاستشعار عن بُعد والخرائط الرقمية والتبليغ الإلكتروني تساعد على كشف بؤر الأمراض مبكرًا وتتبّع حركة القطعان.'],['💚 رفاه الحيوان','الحريات الخمس (الجوع، الانزعاج، الألم، التعبير عن السلوك، الخوف) إطار عالمي لتقييم رعاية الحيوان.'],['🧪 التشخيص الجزيئي','تقنيات PCR وLAMP تكشف مسببات الأمراض بسرعة ودقة، وتدعم برامج الاستئصال والرقابة على الحدود.'],['🎓 المسارات المهنية','عيادة الحيوانات الأليفة، طب المزارع والصحة العامة، البحث والجامعة، الصناعات الدوائية، الرقابة الصحية على الأغذية، والاستشارات الدولية.'],['📘 دليل الطالب','ابدأ بالتشريح والفيزيولوجيا، ثم الأمراض المعدية والباطنة، وتدرّب سريريًا مبكرًا، وتعلّم قراءة الأبحاث بالإنجليزية، واشترك في نوادي علمية.']];
const ad=document.createElement('section');ad.id='advanced';ad.innerHTML='<div class="wrap"><div class="sectionHead"><div><h2>🔭 العلوم والتقنيات البيطرية الحديثة</h2><p class="muted">أحدث اتجاهات الطب البيطري عالميًا، في ملخصات مركّزة. اضغط على أي عنوان.</p></div></div><div class="card">'+AD.map(a=>'<details class="art"><summary>'+a[0]+'</summary><p class="muted">'+a[1]+'</p></details>').join('')+'</div></div>';document.getElementById('slot').append(ad);
const DIR=[['📖 مراجع وأدلة سريرية',[['Merck Veterinary Manual','https://www.merckvetmanual.com','المرجع السريري المجاني الأشهر'],['VIN','https://www.vin.com','شبكة معلومات بيطرية عالمية'],['CABI Digital Library','https://www.cabidigitallibrary.org','موارد الصحة الحيوانية والزراعة'],['WOAH','https://www.woah.org','المعايير الدولية وتقارير الأمراض']]],['🔬 قواعد بيانات الأبحاث',[['PubMed','https://pubmed.ncbi.nlm.nih.gov','ملايين المقالات الطبية'],['PubMed Central','https://pmc.ncbi.nlm.nih.gov','نصوص كاملة مفتوحة'],['Europe PMC','https://europepmc.org','أبحاث الحياة والطب'],['AGRIS (الفاو)','https://agris.fao.org','فهرس الزراعة والثروة الحيوانية'],['Google Scholar','https://scholar.google.com','بحث أكاديمي شامل'],['Semantic Scholar','https://www.semanticscholar.org','بحث ذكي في الأوراق'],['CORE','https://core.ac.uk','أبحاث مفتوحة الوصول'],['BASE','https://www.base-search.net','محرك أكاديمي مفتوح'],['bioRxiv','https://www.biorxiv.org','مسودات الأبحاث قبل التحكيم']]],['📚 كتب ومكتبات رقمية',[['Open Library','https://openlibrary.org','استعارة كتب رقمية'],['Internet Archive','https://archive.org','كتب ووثائق ومجلات'],['HathiTrust','https://www.hathitrust.org','مكتبة رقمية جامعية'],['Project Gutenberg','https://www.gutenberg.org','كتب كلاسيكية حرة'],['Google Books','https://books.google.com','معاينة كتب'],['FAO Publications','https://www.fao.org/publications','منشورات الفاو'],['WHO IRIS','https://iris.who.int','مستودع منظمة الصحة العالمية']]],['📰 مجلات مفتوحة',[['DOAJ','https://doaj.org','دليل المجلات المفتوحة'],['BMC Veterinary Research','https://bmcvetres.biomedcentral.com','مجلة بحثية مفتوحة'],['Frontiers in Veterinary Science','https://www.frontiersin.org/journals/veterinary-science','أبحاث مفتوحة حديثة'],['PLOS ONE','https://journals.plos.org/plosone','مجلة متعددة التخصصات']]],['🇩🇿 مصادر جزائرية',[['ASJP','https://www.asjp.cerist.dz','المنصة الجزائرية للمجلات العلمية'],['SNDL','https://sndl.cerist.dz','النظام الوطني للتوثيق على الخط']]]];
const lb=document.querySelector('#library .wrap');lb.insertAdjacentHTML('beforeend','<div class="tool" style="margin-top:14px"><h3>🗂️ دليل المكتبات والبحوث البيطرية</h3><p class="small">بوابات إلى ملايين الكتب والأبحاث؛ الموقع يوجّهك ولا يستضيف المحتوى.</p><input id="dq" placeholder="ابحث في الدليل..."><div id="dirs"></div></div>');
$('#dirs').innerHTML=DIR.map(c=>'<h3 style="margin-top:12px">'+c[0]+'</h3>'+c[1].map(l=>'<a class="dl" target="_blank" rel="noopener" href="'+l[1]+'"><b>'+l[0]+'</b><span>'+l[2]+'</span></a>').join('')).join('');
$('#dq').oninput=e=>{const q=e.target.value.toLowerCase();$$('.dl').forEach(a=>a.style.display=a.textContent.toLowerCase().includes(q)?'block':'none')};
$('#chat h2').textContent='🧠 بيطري-AI — مساعد المنصة';$('#chat .muted').textContent='مساعد خاص بالمنصة، يتذكر محادثاتك السابقة في هذا المتصفح. يجيب عن مختلف المواضيع، وإجاباته الطبية تعليمية ولا تغني عن الطبيب.';
const MK='vetai_mem';let H=[];try{H=JSON.parse(localStorage.getItem(MK)||'[]')}catch(e){}
H.forEach(m=>add(m.t,m.r));
$('#chat .tool').insertAdjacentHTML('beforeend','<button class="btn alt" id="fg">🧹 مسح الذاكرة</button>');
$('#fg').onclick=()=>{H=[];try{localStorage.removeItem(MK)}catch(e){}$('#msgs').innerHTML='<div class="m b">تم مسح الذاكرة.</div>'};
function sv(){try{localStorage.setItem(MK,JSON.stringify(H.slice(-20)))}catch(e){}}
async function ask(q){add(q,'u');H.push({t:q,r:'u'});const b=add('…','b');let sm=null;try{sm=window.claude&&await claude.use('sample')}catch(e){}
let out=null;if(sm){try{const ctx=H.slice(-7,-1).map(m=>(m.r=='u'?'المستخدم: ':'بيطري-AI: ')+m.t).join('\n');const r=await sm([{role:'user',content:'أنت «بيطري-AI»، المساعد الرسمي لمنصة الدكتور محجوبي عبدالناصر البيطرية. أجب عن أي سؤال في أي موضوع، بلغة السائل وبدقة ووضوح ودون اختلاق، وإن لم تكن متأكدًا فاذكر ذلك. للأسئلة الطبية والبيطرية لا تعطِ جرعات علاجية محددة وانصح بالطبيب في الحالات الطارئة.\nالمحادثة السابقة:\n'+ctx+'\nالسؤال: '+q}],{cache:false,onText:({text})=>{b.textContent=text}});out=r.text}catch(e){}}
if(!out)out=local(q);b.textContent=out;H.push({t:out,r:'b'});sv()}
addEventListener('scroll',()=>{const h=document.documentElement;$('#pg').style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight)*100)+'%'});
$('#up').onclick=()=>scrollTo({top:0,behavior:'smooth'});

document.addEventListener('click',e=>{const a=e.target.closest('[data-go]');if(!a)return;e.preventDefault();go2(a.dataset.go.replace('#',''))});
function go2(id){const m={today:'home',smart:'ai-diagnostics',tools:'ai-diagnostics',chat:'chat',knowledge:'knowledge',advanced:'knowledge',research:'knowledge',library:'library',services:'services',unis:'universities',games:'fun',media:'fun',contact:'creator'};switchTab(m[id]||id);setTimeout(()=>{const el=document.getElementById(id);el&&el.scrollIntoView({behavior:'smooth'})},120)}
