/* 14-visitor-counter */
/* عداد الزوار: يظهر فقط إذا وضعت رابط خدمة عدّاد حقيقية في js/config.js (VET_VISITOR_COUNTER_URL).
   خدمة countapi.xyz السابقة متوقفة، والرقم الثابت 135,322 كان رقمًا وهميًا فأُخفي. */
(function(){var el=document.getElementById('live-visitors-count');if(!el)return;var box=el.closest('div'),url=window.VET_VISITOR_COUNTER_URL||'';
function off(){box.style.display='none'}if(!url){off();return}
fetch(url).then(function(r){return r.json()}).then(function(d){if(d&&d.value!=null)el.textContent=Number(d.value).toLocaleString('en-US');else off()}).catch(off)})();
