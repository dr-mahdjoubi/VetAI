/* 05-games */
(function(){const q=s=>document.querySelector(s),sh=a=>a.map(x=>[Math.random(),x]).sort((a,b)=>a[0]-b[0]).map(x=>x[1]);
// animal background floaters
const F=["🐕", "🐈", "🐄", "🐑", "🐓", "🐎", "🐇", "🦜", "🐐", "🐖", "🐪", "🐘", "🦒", "🦓", "🦁", "🐅", "🐒", "🐊", "🐢", "🐍", "🐸", "🐟", "🐬", "🐋", "🦈", "🐙", "🦀", "🦋", "🐝", "🦉", "🦅", "🦆", "🦢", "🐧", "🦩", "🦔", "🦊", "🐺", "🐻", "🐼", "🦘", "🦥", "🦦", "🐿️"],fl=q('#fl');if(fl){fl.innerHTML='';F.forEach((a,i)=>{const s=document.createElement('span');s.textContent=a;s.style.left=(i*100/F.length)+'%';s.style.animationDuration=(20+i%7*4)+'s';s.style.animationDelay='-'+(i*2.3)+'s';fl.append(s)})}
// whack
let wt=null,ws=0,wl=30,wi=null;const wm=q('#wm');wm.innerHTML=[...Array(9)].map(()=>'<button></button>').join('');
function wend(){clearInterval(wt);clearInterval(wi);wm.querySelectorAll('button').forEach(b=>b.textContent='');q('#wms').textContent='انتهى! نقاطك: '+ws+(ws>=20?' 🏆':ws>=10?' 👏':' 💪')}
q('#wmgo').onclick=()=>{ws=0;wl=30;clearInterval(wt);clearInterval(wi);q('#wms').textContent='النقاط: 0 · الوقت: 30';wt=setInterval(()=>{wl--;q('#wms').textContent='النقاط: '+ws+' · الوقت: '+wl;if(wl<=0)wend()},1000);wi=setInterval(()=>{const bs=wm.querySelectorAll('button');bs.forEach(b=>b.textContent='');bs[Math.floor(Math.random()*9)].textContent=F[Math.floor(Math.random()*12)]},750)};
wm.onclick=e=>{const b=e.target.closest('button');if(b&&b.textContent&&wl>0){ws++;b.textContent='⭐';q('#wms').textContent='النقاط: '+ws+' · الوقت: '+wl}};
// young
const Y=[['الخروف','الحمل'],['البقرة','العجل'],['الدجاجة','الكتكوت'],['الحصان','المهر'],['الكلب','الجرو'],['الماعز','الجدي'],['الناقة','الحوار'],['الأسد','الشبل'],['الضفدع','الشرغوف'],['القطة','الهريرة']];let yc=0,ya;
function yn(){const c=Y[Math.floor(Math.random()*Y.length)];ya=c[1];q('#yq').textContent='ما اسم صغير: '+c[0]+'؟';q('#yo').innerHTML=sh([c[1]].concat(sh(Y.filter(x=>x[1]!=c[1])).slice(0,2).map(x=>x[1]))).map(o=>'<button class="btn alt quizOpt">'+o+'</button>').join('')}
q('#yo').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.textContent==ya){yc++;b.textContent='✅ '+b.textContent}else{b.textContent='❌ الصحيح: '+ya;yc=Math.max(0,yc-1)}q('#ys').textContent='النقاط: '+yc;setTimeout(yn,900)};yn();
// true/false
const T=[['للأخطبوط ثلاثة قلوب.',1],['الخفافيش عمياء تمامًا.',0],['الزرافة لها سبع فقرات عنقية.',1],['يخزن الجمل الماء في سنامه.',0],['الدلفين من الثدييات.',1],['العنكبوت حشرة.',0],['الأبقار حيوانات مجترة.',1],['الدجاج يطير لمسافات بعيدة.',0],['الكلاب ترى الألوان بدرجة أقل من الإنسان.',1],['تنام القطط أقل من 4 ساعات يوميًا.',0]];let ti=0,tc=0;
function tn(){ti=Math.floor(Math.random()*T.length);q('#tq').textContent=T[ti][0]}
document.addEventListener('click',e=>{const b=e.target.closest('[data-tf]');if(!b)return;const ok=(+b.dataset.tf)==T[ti][1];if(ok)tc++;q('#tr').textContent=ok?'✅ إجابة صحيحة':'❌ الصحيح: '+(T[ti][1]?'صح':'خطأ');q('#ts').textContent='النقاط: '+tc;tn()});tn();
// scramble
const W=['أسد','حصان','زرافة','دلفين','غزال','نعامة','سلحفاة','فيل','خروف','ثعلب'];let wd='',sc=0;
function sn(){wd=W[Math.floor(Math.random()*W.length)];let s;do{s=sh(wd.split('')).join('')}while(s==wd);q('#sw').textContent=s.split('').join(' ');q('#si').value='';q('#sr').textContent='—'}
q('#sc').onclick=()=>{if(q('#si').value.trim()==wd){sc++;q('#ss').textContent='النقاط: '+sc;q('#sr').textContent='🎉 صحيح!';setTimeout(sn,900)}else q('#sr').textContent='حاول مجددًا'};
q('#sh2').onclick=()=>q('#sr').textContent='يبدأ بحرف: '+wd[0]+' · عدد الحروف: '+wd.length;sn();})();
