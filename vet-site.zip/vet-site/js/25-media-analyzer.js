/* 25-media-analyzer */
(function(){
/* عنوان الخادم الوسيط الذي يحمل مفتاح API (لا تضع المفتاح هنا أبدًا) */
var ENDPOINT=window.VET_AI_ENDPOINT||"/api/vet-ai";
var $=function(i){return document.getElementById(i)},imgs=[];
var dlg=$("vx-dlg");
$("vx-open").onclick=function(){dlg.showModal()};
dlg.addEventListener("click",function(e){if(e.target===dlg)dlg.close()});

function loadImg(s){return new Promise(function(r,j){var i=new Image();i.onload=function(){r(i)};i.onerror=j;i.src=s})}
function jpeg(el,w,h){var k=Math.min(1,1600/Math.max(w,h)),c=document.createElement("canvas");c.width=Math.round(w*k);c.height=Math.round(h*k);c.getContext("2d").drawImage(el,0,0,c.width,c.height);return c.toDataURL("image/jpeg",.85)}
function fromVideo(f){return new Promise(function(res,rej){
  var v=document.createElement("video"),u=URL.createObjectURL(f),o=[];
  v.muted=true;v.preload="auto";v.src=u;
  v.onerror=function(){rej(new Error("تعذّر قراءة الفيديو"))};
  v.onloadedmetadata=async function(){
    if(v.duration>30){URL.revokeObjectURL(u);return rej(new Error("الفيديو أطول من 30 ثانية"))}
    for(var k=0;k<4;k++){v.currentTime=v.duration*(k+.5)/4;await new Promise(function(r){v.onseeked=r});o.push(jpeg(v,v.videoWidth,v.videoHeight))}
    URL.revokeObjectURL(u);res(o)}})}
function show(t,err){var o=$("vx-out");o.textContent=t;o.className=err?"err":"";o.style.display=t?"block":"none"}

async function handle(files){
  var l=[].slice.call(files);imgs=[];$("vx-thumbs").innerHTML="";show("");
  try{
    var vid=l.find(function(f){return f.type.indexOf("video/")===0});
    if(vid){imgs=await fromVideo(vid)}
    else{for(var f of l.filter(function(f){return f.type.indexOf("image/")===0}).slice(0,4)){
      var u=URL.createObjectURL(f),im=await loadImg(u);imgs.push(jpeg(im,im.naturalWidth,im.naturalHeight));URL.revokeObjectURL(u)}}
  }catch(e){show(e.message,true)}
  imgs.forEach(function(d){var i=document.createElement("img");i.src=d;i.alt="معاينة";$("vx-thumbs").appendChild(i)});
  $("vx-go").disabled=!imgs.length;
}
$("vx-file").onchange=function(e){handle(e.target.files)};
var dz=$("vx-drop");
["dragover","dragenter"].forEach(function(n){dz.addEventListener(n,function(e){e.preventDefault();dz.classList.add("over")})});
["dragleave","drop"].forEach(function(n){dz.addEventListener(n,function(e){e.preventDefault();dz.classList.remove("over")})});
dz.addEventListener("drop",function(e){handle(e.dataTransfer.files)});

$("vx-go").onclick=async function(){
  var b=$("vx-go");b.disabled=true;b.textContent="جارٍ التحليل...";show("");
  try{
    var r=await fetch(ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      kind:document.querySelector("input[name=vxk]:checked").value,species:$("vx-sp").value,notes:$("vx-notes").value.trim(),images:imgs})});
    if(!r.ok)throw new Error("تعذّر إكمال التحليل (رمز "+r.status+"). حاول بعد قليل.");
    var d=await r.json();show(d.text||"لم تصل نتيجة. جرّب صورة أوضح.");
  }catch(e){show(e.message||"حدث خطأ في الاتصال.",true)}
  b.textContent="حلّل الآن";b.disabled=!imgs.length;
};
})();
