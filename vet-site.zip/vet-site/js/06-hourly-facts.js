/* 06-hourly-facts */
(function(){const q=s=>document.querySelector(s),POOL=window.VET_CONTENT.hourlyFacts,TOP=window.VET_CONTENT.hourlyTopics;let feed=[],last=-1;try{feed=JSON.parse(localStorage.getItem('hrfeed')||'[]')}catch(e){}
const hk=()=>Math.floor(Date.now()/36e5);
function render(){const d=new Date();q('#hrTxt').textContent='💡 '+POOL[hk()%POOL.length];q('#hrTime').textContent='آخر تحديث: '+d.toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit'});q('#hrNext').textContent='⏳ التحديث التالي بعد '+(60-d.getMinutes())+' دقيقة';last=hk()}
function paint(){const f=q('#hrFeed');f.innerHTML='';feed.slice(-8).reverse().forEach(x=>{const d=document.createElement('details');d.className='border-t border-slate-800 py-2';const s=document.createElement('summary');s.className='cursor-pointer text-sm font-bold text-sky-300';s.textContent=x.h+' · '+x.t;const p=document.createElement('p');p.className='text-sm text-slate-300 mt-1';p.textContent=x.x;d.append(s,p);f.append(d)})}
async function gen(){const st=q('#hrSt');let s=null;try{s=window.claude&&await claude.use('sample')}catch(e){}
if(!s){st.textContent='ميزة التوليد غير متاحة في هذا العرض.';return false}
const t=TOP[hk()%TOP.length];st.textContent='⏳ جارٍ توليد معلومة عن: '+t;
try{const r=await s('اكتب معلومة جديدة ومفيدة وصحيحة بالعربية عن موضوع «'+t+'» في الطب البيطري والعلوم المرتبطة في 3 جمل، دون جرعات علاجية، وتجنب تكرار: '+feed.slice(-5).map(x=>x.x.slice(0,40)).join(' | ')+'. أعد النص فقط.',{cache:false});
feed.push({t,h:new Date().toLocaleTimeString('ar-DZ',{hour:'2-digit',minute:'2-digit'}),x:r.text});feed=feed.slice(-20);try{localStorage.setItem('hrfeed',JSON.stringify(feed))}catch(e){}paint();st.textContent='✅ أضيفت معلومة جديدة';return true}catch(e){st.textContent='تعذّر التوليد الآن؛ حاول لاحقًا.';return false}}
q('#hrGen').onclick=gen;
const on=q('#hrOn');try{on.checked=localStorage.getItem('hron')=='1'}catch(e){}
on.onchange=()=>{try{localStorage.setItem('hron',on.checked?'1':'0')}catch(e){}if(on.checked)gen()};
render();paint();let lastGen=hk();
setInterval(()=>{if(hk()!=last)render();else q('#hrNext').textContent='⏳ التحديث التالي بعد '+(60-new Date().getMinutes())+' دقيقة';if(on.checked&&hk()!=lastGen){lastGen=hk();gen()}},60000);
// quick ask button
const b=document.createElement('button');b.id='askfab';b.textContent='🧠 اسأل';b.onclick=()=>{switchTab('chat');setTimeout(()=>{const i=document.getElementById('cq');i&&i.focus()},200)};document.body.append(b);})();
