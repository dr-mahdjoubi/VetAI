/* 23-animal-video */
/* بطاقة «موضوع اليوم»: إن وُجد الملف media/animals.mp4 يحلّ فيديو قصير متكرر محل الإيموجي، وإلا يبقى الإيموجي كما هو */
(function(){
  function build(pic){
    var v=document.createElement('video');
    v.muted=true;v.defaultMuted=true;v.loop=true;v.autoplay=true;v.playsInline=true;
    v.setAttribute('playsinline','');v.setAttribute('muted','');v.preload='metadata';
    v.setAttribute('aria-hidden','true');
    v.style.cssText='width:100%;height:100%;object-fit:cover;border-radius:inherit;display:block';
    var s=document.createElement('source');s.src='media/animals.mp4';s.type='video/mp4';v.appendChild(s);
    v.addEventListener('loadeddata',function(){
      pic.textContent='';pic.style.overflow='hidden';pic.style.padding='0';pic.appendChild(v);
      pic.setAttribute('role','img');pic.setAttribute('aria-label','حيوانات أليفة ومزرعة');
      var p=v.play();if(p&&p.catch)p.catch(function(){});
      if('IntersectionObserver' in window){
        new IntersectionObserver(function(es){es.forEach(function(e){
          if(e.isIntersecting){var q=v.play();if(q&&q.catch)q.catch(function(){});}else v.pause();
        });},{threshold:.15}).observe(pic);
      }
    },{once:true});
    v.load();
  }
  function apply(){
    var pic=Array.prototype.slice.call(document.querySelectorAll('.pic')).filter(function(e){
      return e.textContent.indexOf('🐕')>-1&&e.textContent.indexOf('🐄')>-1;})[0];
    if(!pic||pic.dataset.vid)return;
    pic.dataset.vid='1';
    var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
    var sd=navigator.connection&&navigator.connection.saveData;
    if(rm||sd)return;                       // احترام تقليل الحركة وتوفير البيانات
    fetch('media/animals.mp4',{method:'HEAD',cache:'no-store'}).then(function(r){if(r.ok)build(pic);}).catch(function(){});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
})();
