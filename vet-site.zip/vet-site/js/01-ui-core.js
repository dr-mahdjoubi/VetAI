/* 01-ui-core */

        function switchTab(tabId) {
            const tabs = ['catalog', 'home', 'ai-diagnostics', 'chat', 'knowledge', 'ref', 'drugs', 'dxlab', 'exams', 'library', 'services', 'fun', 'creator', 'about', 'legal'];
            tabs.forEach(t => {
                const el = document.getElementById('view-' + t);
                const btn = document.getElementById('btn-' + t);
                if (el) el.classList.add('hidden');
                if (btn) {
                    btn.classList.remove('bg-vetCyan', 'text-vetDark', 'shadow-md');
                    btn.classList.add('text-slate-300', 'hover:text-white', 'hover:bg-slate-800');
                }
            });

            const targetEl = document.getElementById('view-' + tabId);
            const targetBtn = document.getElementById('btn-' + tabId);
            if (targetEl) targetEl.classList.remove('hidden');
            if (targetBtn) {
                targetBtn.classList.remove('text-slate-300', 'hover:text-white', 'hover:bg-slate-800');
                targetBtn.classList.add('bg-vetCyan', 'text-vetDark', 'shadow-md');
            }
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        function alertCustom(message) {
            document.getElementById('modal-message').innerText = message;
            document.getElementById('custom-modal').classList.remove('hidden');
            document.getElementById('custom-modal').classList.add('flex');
        }

        function closeCustomModal() {
            document.getElementById('custom-modal').classList.remove('flex');
            document.getElementById('custom-modal').classList.add('hidden');
        }

        function openDailyUpdateModal() {
            document.getElementById('daily-update-modal').classList.remove('hidden');
            document.getElementById('daily-update-modal').classList.add('flex');
        }

        function closeDailyUpdateModal() {
            document.getElementById('daily-update-modal').classList.remove('flex');
            document.getElementById('daily-update-modal').classList.add('hidden');
        }

        async function runAIDiagnosis() {
            const sp=document.getElementById('diag-species').value,sy=document.getElementById('diag-symptoms').value.trim(),ex=(document.getElementById('diag-extra')||{}).value||'';
            const box=document.getElementById('diag-result-box'),badge=document.getElementById('diag-status-badge');
            if(!sy){alertCustom('اكتب الأعراض أولًا.');return}
            const red=/نزيف|تشنج|اختناق|صعوبة (في )?التنفس|انهيار|إغماء|غيبوبة|انتفاخ|لا يتبول|تسمم|سم |حادث|كسر|عسر ولادة|ولادة عسرة|قيء دموي|إسهال دموي|لثة شاحبة|لثة زرقاء/.test(sy);
            badge.innerText='جارٍ التقييم...';box.innerHTML='<p class="text-slate-300">⏳ جارٍ التقييم...</p>';
            let t=null;
            try{const s=window.claude&&await claude.use('sample');if(s){const r=await s('أنت مساعد بيطري تعليمي. النوع: '+sp+'. العمر/المدة: '+ex+'. الأعراض: '+sy+'. أجب بالعربية بإيجاز وبعناوين: 1) درجة الاستعجال (طارئ الآن / مراجعة خلال 24 ساعة / مراقبة) مع السبب، 2) احتمالات تعليمية (ثلاثة كحد أقصى)، 3) فحوصات قد يطلبها الطبيب، 4) ما تفعله الآن بأمان، 5) علامات تستدعي الطوارئ. لا جرعات ولا أدوية بعينها، وأكّد أن هذا ليس تشخيصًا.',{cache:false});t=r.text}}catch(e){}
            const lvl=red?'🔴 يُرجَّح أنها حالة عاجلة: اتصل بالطبيب فورًا':'🟡 راجع الطبيب إن استمرت الأعراض أو ساءت';
            badge.innerText=t?'تقييم إرشادي (ذكاء اصطناعي)':'تقييم إرشادي (قواعد بسيطة)';
            box.className='bg-slate-950 p-6 rounded-2xl border border-slate-800 text-slate-300 text-xs leading-relaxed min-h-[220px] text-right';
            box.innerHTML='<div class="space-y-3 w-full"><div class="p-3 rounded-xl bg-slate-900 border border-slate-800"><b>درجة الاستعجال:</b> '+lvl+'</div>'+(t?'<div id="diag-ai" class="p-3 rounded-xl bg-slate-900 border border-slate-800 whitespace-pre-wrap text-slate-200 text-sm"></div>':'<div class="p-3 rounded-xl bg-slate-900 border border-slate-800 text-sm">لم يتوفر المساعد الذكي الآن (قد تحتاج الموافقة على تفعيله). نصائح عامة: راقب الشهية والشرب والتنفس والنشاط، وسجّل المدة، ولا تعطِ أي دواء دون طبيب. يمكنك إرسال التفاصيل للدكتور من «اطرح حالة» في المرجع السريري.</div>')+'<div class="text-[11px] text-slate-400">تقييم إرشادي تعليمي وليس تشخيصًا ولا يغني عن الفحص البيطري.</div></div>';
            if(t)document.getElementById('diag-ai').textContent=t;
        }

        function escapeHtml(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) { return map[m]; });
        }
