/* 03-fun-burst */
const FACTS=window.VET_CONTENT.funFacts;
document.getElementById('fun').onclick=()=>{alertCustom('🎉 هل تعلم؟ '+FACTS[Math.floor(Math.random()*FACTS.length)]);const E=['🐾','🐕','🐈','🐄','🐑','⭐','🎈'];for(let i=0;i<16;i++){const s=document.createElement('span');s.className='bst';s.textContent=E[i%E.length];s.style.left=innerWidth-60+'px';s.style.top=innerHeight-70+'px';s.style.setProperty('--x',(-Math.random()*innerWidth*.6)+'px');s.style.setProperty('--y',(-Math.random()*innerHeight*.6)+'px');document.body.append(s);setTimeout(()=>s.remove(),1500)}};
