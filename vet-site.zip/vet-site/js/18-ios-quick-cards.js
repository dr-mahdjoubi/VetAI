/* 18-ios-quick-cards */
/* بطاقات «الوصول السريع» بأسلوب أيقونات الآيفون — ألوان وشكل البطاقات فقط */
(function(){
  function apply(){
    var h=Array.prototype.slice.call(document.querySelectorAll('h2')).filter(function(x){return /الوصول السريع/.test(x.textContent);})[0];
    if(!h)return;
    var bar=h.parentElement,grid=bar&&bar.nextElementSibling;
    if(!grid||!grid.querySelector('button')||grid.classList.contains('ios-quick'))return;
    grid.classList.add('ios-quick');
    if(document.getElementById('ios-quick-css'))return;
    var s=document.createElement('style');s.id='ios-quick-css';
    var g=[['#bf5af2','#5e5ce6'],['#0a84ff','#5ac8fa'],['#34c759','#0a9d58'],['#ff375f','#ff2d55'],['#ff9f0a','#ff5e00'],['#00c7be','#0a84ff'],['#ffd60a','#ff9f0a'],['#5e5ce6','#bf5af2']];
    var css='.ios-quick>button{border:0!important;color:#fff!important;border-radius:24px!important;box-shadow:0 8px 20px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.35)!important;transition:transform .15s ease,filter .15s ease!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important}'+
    '.ios-quick>button:hover{filter:saturate(1.15)}'+
    '.ios-quick>button:active{transform:scale(.95)!important}'+
    '.ios-quick>button *{color:#fff!important}'+
    '.ios-quick>button>div:first-child{background:rgba(255,255,255,.28)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.5)!important;width:3.25rem!important;height:3.25rem!important;border-radius:16px!important;font-size:2rem!important}'+
    '.ios-quick>button .font-black{font-weight:800!important;text-shadow:0 1px 2px rgba(0,0,0,.35)}'+
    '.ios-quick>button .text-\\[11px\\]{color:rgba(255,255,255,.92)!important}';
    g.forEach(function(x,i){css+='.ios-quick>button:nth-child('+(i+1)+'){background:linear-gradient(145deg,'+x[0]+','+x[1]+')!important}';});
    css+='@media(prefers-reduced-motion:reduce){.ios-quick>button{transition:none!important}.ios-quick>button:active{transform:none!important}}';
    s.textContent=css;document.head.appendChild(s);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
  window.addEventListener('load',apply);
})();
