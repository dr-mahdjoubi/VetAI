/* 10-home-search-chips */
(function(){const g=id=>document.getElementById(id);
function go(t){const gs=g('gs');if(!gs||!t)return;gs.value=t;gs.dispatchEvent(new Event('input'));window.scrollTo({top:0,behavior:'smooth'});gs.focus()}
const askAI=t=>{if(window.vetAIAsk)window.vetAIAsk(t);else go(t)};
g('hsb').onclick=()=>askAI(g('hs').value.trim());g('hs').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();askAI(g('hs').value.trim())}};
document.querySelectorAll('.hsc').forEach(b=>b.onclick=()=>{g('hs').value=b.textContent;askAI(b.textContent)});
const R=window.__refR||[],pick=['السعار','الباروفيروس','التهاب الضرع','الإنفلونزا الطيرية','الجلد العقدي','الليشمانيا الكلبية'];
g('homeArts').innerHTML=pick.map(t=>{const i=R.findIndex(r=>r[0]==t);return i<0?'':'<button data-a="'+i+'" class="text-right rounded-2xl glass-panel p-4 hover:border-vetCyan transition"><div class="text-[11px] text-slate-400">'+R[i][1]+'</div><div class="font-black mt-1">'+R[i][0]+'</div><p class="text-xs text-slate-300 mt-1 leading-relaxed">'+R[i][8]+'</p><span class="text-xs text-sky-300">اقرأ المقال ←</span></button>'}).join('');
g('homeArts').onclick=e=>{const b=e.target.closest('[data-a]');if(b){switchTab('ref');window.__ref&&window.__ref('a:'+b.dataset.a)}};})();
