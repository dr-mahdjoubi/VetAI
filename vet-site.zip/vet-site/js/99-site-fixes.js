/* 99-site-fixes: إصلاحات الأزرار والتنقل + عرض المقالات اليومية (يُحمَّل أخيرًا) */
(function(){
  var C=window.VET_CONTENT||{};

  /* 1) المقالات الجديدة تُرسم من data/daily-content.js */
  var box=document.getElementById('newArticles');
  if(box)(C.articles||[]).forEach(function(a){
    var d=document.createElement('details'),s=document.createElement('summary'),p=document.createElement('p');
    d.className='art';p.className='muted';
    s.textContent=(a.icon?a.icon+' ':'')+a.title;p.textContent=a.text;
    d.append(s,p);box.append(d);
  });

  /* 2) روابط href="#": لا تقفز للأعلى ولا تغيّر العنوان */
  document.addEventListener('click',function(e){
    if(e.target.closest('a[href="#"]'))e.preventDefault();
  },true);

  /* 3) التنقل: لا شاشة فارغة أبدًا؛ «الجامعات» تمرّر للقسم، وأي اسم مجهول يعود للرئيسية */
  var UNI=/^(uni|unis|universities)$/,_st=window.switchTab,_go2=window.go2;
  function toUni(){var u=document.getElementById('uni-end');u&&u.scrollIntoView({behavior:'smooth'})}
  window.switchTab=function(t){
    if(UNI.test(t))return toUni();
    _st(document.getElementById('view-'+t)?t:'home');
  };
  window.go2=function(id){UNI.test(id)?toUni():_go2(id)};

  /* 4) النوافذ المنبثقة: Esc أو الضغط على الخلفية يغلقها */
  var M=['custom-modal','daily-update-modal'].map(function(i){return document.getElementById(i)}).filter(Boolean);
  function shut(m){m.classList.add('hidden');m.classList.remove('flex')}
  document.addEventListener('keydown',function(e){if(e.key==='Escape')M.forEach(shut)});
  M.forEach(function(m){m.addEventListener('click',function(e){if(e.target===m)shut(m)})});
})();
