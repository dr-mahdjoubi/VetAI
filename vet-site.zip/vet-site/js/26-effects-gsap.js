/* 26-effects-gsap */
/* ===== طبقة التأثيرات: GSAP + ScrollTrigger + Lenis + تأثيرات على طراز React Bits ===== */
(function () {
  'use strict';
  var root = document.documentElement;
  var reduce = matchMedia('(prefers-reduced-motion:reduce)').matches;
  function unlock() { root.classList.remove('rb-pre'); }
  // إن تعذّر تحميل GSAP أو فضّل المستخدم تقليل الحركة: يبقى الموقع كما هو تمامًا
  if (reduce || !window.gsap) { unlock(); return; }

  var gsap = window.gsap, ST = window.ScrollTrigger;
  if (ST) gsap.registerPlugin(ST);
  var fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  function safe(f) { try { f(); } catch (e) { if (window.console) console.warn('[fx]', e); } }

  var hero = document.querySelector('#view-home > div:first-child');
  var lenis = null;

  /* ---------- 1) Lenis: تمرير سلس ---------- */
  safe(function () {
    ['gsr', 'custom-modal'].forEach(function (id) {
      var el = document.getElementById(id); if (el) el.setAttribute('data-lenis-prevent', '');
    });
    if (!window.Lenis) return;
    lenis = new Lenis({
      duration: 1.1,
      easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
      smoothWheel: true,
      wheelMultiplier: 0.95,
      touchMultiplier: 1.3,
      allowNestedScroll: true,
      prevent: function (n) {
        return !!(n && n.closest && n.closest('[data-lenis-prevent],#gsr,#custom-modal,textarea,select,pre'));
      }
    });
    window.__lenis = lenis;
    if (ST) lenis.on('scroll', ST.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);

    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[href^="#"]');
      if (!a) return;
      var id = a.getAttribute('href');
      if (!id || id.length < 2) return;
      try {
        var t = document.querySelector(id);
        if (!t || t.offsetParent === null) return;
        e.preventDefault();
        lenis.scrollTo(t, { offset: -110 });
      } catch (err) {}
    });
  });

  /* ---------- 2) شريط تقدّم القراءة ---------- */
  safe(function () {
    var bar = document.createElement('div');
    bar.id = 'rb-progress'; bar.setAttribute('aria-hidden', 'true');
    document.body.appendChild(bar);
    var set = gsap.quickSetter(bar, 'scaleX');
    function upd() {
      var h = document.documentElement.scrollHeight - innerHeight;
      set(h > 0 ? Math.min(1, scrollY / h) : 0);
    }
    addEventListener('scroll', upd, { passive: true });
    addEventListener('resize', upd);
    upd();
  });

  /* ---------- 3) الهيرو: Aurora + ظهور الكلمات + عدّاد الأرقام ---------- */
  function splitWords(el) {
    // تقسيم إلى كلمات (لا حروف) حتى لا تنفصل الحروف العربية المتصلة
    (function walk(n) {
      [].slice.call(n.childNodes).forEach(function (c) {
        if (c.nodeType === 3) {
          var f = document.createDocumentFragment();
          c.nodeValue.split(/(\s+)/).forEach(function (p) {
            if (!p) return;
            if (/^\s+$/.test(p)) { f.appendChild(document.createTextNode(' ')); return; }
            var w = document.createElement('span'); w.className = 'rb-w';
            var i = document.createElement('span'); i.className = 'rb-wi'; i.textContent = p;
            w.appendChild(i); f.appendChild(w);
          });
          c.replaceWith(f);
        } else if (c.nodeType === 1 && c.tagName !== 'BR') walk(c);
      });
    })(el);
  }

  safe(function () {
    if (!hero) return;
    var au = document.createElement('div');
    au.className = 'rb-aurora'; au.setAttribute('aria-hidden', 'true');
    au.innerHTML = '<i></i><i></i><i></i>';
    hero.insertBefore(au, hero.firstChild);

    au.querySelectorAll('i').forEach(function (b) {
      gsap.to(b, {
        x: function () { return gsap.utils.random(-90, 90); },
        y: function () { return gsap.utils.random(-50, 50); },
        scale: function () { return gsap.utils.random(0.85, 1.3); },
        duration: gsap.utils.random(7, 11), ease: 'sine.inOut',
        repeat: -1, yoyo: true, repeatRefresh: true
      });
    });
    if (ST) {
      gsap.to(au, { yPercent: 12, ease: 'none',
        scrollTrigger: { trigger: hero, start: 'top top', end: 'bottom top', scrub: 0.6 } });
    }

    var badge = hero.querySelector('span.inline-block');
    var h1 = hero.querySelector('h1');
    var p = hero.querySelector('p');
    var rest = [].filter.call(hero.children, function (c) { return c !== au && c !== badge && c !== h1 && c !== p; });

    if (h1) {
      var g = h1.querySelector('.text-vetCyan'); if (g) g.classList.add('rb-grad');
      h1.setAttribute('aria-label', h1.textContent.replace(/\s+/g, ' ').trim());
      splitWords(h1);
    }
    var words = h1 ? h1.querySelectorAll('.rb-wi') : [];

    var tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    if (badge) tl.from(badge, { opacity: 0, y: -14, duration: 0.6 });
    if (words.length) tl.from(words, { opacity: 0, yPercent: 60, filter: 'blur(14px)', duration: 0.9, stagger: 0.1,
      clearProps: 'filter,transform,opacity' }, badge ? '-=0.3' : 0);
    if (p) tl.from(p, { opacity: 0, y: 16, duration: 0.7, clearProps: 'transform,opacity' }, '-=0.5');
    if (rest.length) tl.from(rest, { opacity: 0, y: 18, duration: 0.6, stagger: 0.09,
      clearProps: 'transform,opacity' }, '-=0.45');
    unlock();

    // عدّاد الأرقام (CountUp)
    hero.querySelectorAll('.grid .text-2xl.font-black').forEach(function (el) {
      var m = el.textContent.trim().match(/^(\d+)(.*)$/);
      if (!m) return;
      var end = +m[1], suf = m[2], o = { v: 0 };
      el.textContent = '0' + suf;
      var tn = el.firstChild;
      gsap.to(o, { v: end, duration: 1.8, delay: 1.3, ease: 'power2.out',
        onUpdate: function () { tn.nodeValue = Math.round(o.v) + suf; } });
    });
  });
  unlock();

  /* ---------- 4) ظهور العناصر عند التمرير (ScrollReveal) ---------- */
  safe(function () {
    var REV = '.my .card,.my .tool,.my .stat,.sectionHead,main h2,main details.art,main .glass-panel,#view-home .vx-an';
    var seen = new WeakSet(), q = [], raf = 0;

    function flush() {
      raf = 0;
      var els = q.splice(0);
      if (!els.length) return;
      els.forEach(function (e) { e.classList.add('rb-anim'); });
      gsap.to(els, { opacity: 1, y: 0, duration: 0.75, ease: 'power3.out', overwrite: 'auto',
        stagger: { amount: Math.min(0.6, els.length * 0.06) }, clearProps: 'transform,opacity',
        onComplete: function () { els.forEach(function (e) { e.classList.remove('rb-anim'); }); } });
    }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { io.unobserve(e.target); q.push(e.target); } });
      if (q.length && !raf) raf = requestAnimationFrame(flush);
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.04 });

    function scan() {
      document.querySelectorAll(REV).forEach(function (el) {
        if (seen.has(el)) return;
        seen.add(el);
        if (hero && (el === hero || hero.contains(el))) return;
        if (el.parentElement && el.parentElement.closest(REV)) return;
        gsap.set(el, { opacity: 0, y: 26 });
        io.observe(el);
      });
    }
    scan();
    addEventListener('load', scan);

    var mt, main = document.querySelector('main') || document.body;
    new MutationObserver(function (ms) {
      var ok = ms.some(function (m) {
        return m.addedNodes.length && !(m.target.closest && m.target.closest('#chat,#gsr,.ticker-wrap,[aria-live]'));
      });
      if (!ok) return;
      clearTimeout(mt); mt = setTimeout(scan, 200);
    }).observe(main, { childList: true, subtree: true });
  });

  /* ---------- 5) انتقال سلس بين التبويبات ---------- */
  safe(function () {
    var views = [].slice.call(document.querySelectorAll('[id^="view-"]')), state = new Map();
    views.forEach(function (v) { state.set(v, !v.classList.contains('hidden')); });
    var vmo = new MutationObserver(function (ms) {
      ms.forEach(function (m) {
        var v = m.target, vis = !v.classList.contains('hidden');
        if (vis && !state.get(v)) {
          if (lenis) lenis.scrollTo(0, { immediate: true });
          gsap.fromTo(v, { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.45, ease: 'power3.out', clearProps: 'transform,opacity' });
          if (ST) setTimeout(function () { ST.refresh(); }, 80);
        }
        state.set(v, vis);
      });
    });
    views.forEach(function (v) { vmo.observe(v, { attributes: true, attributeFilter: ['class'] }); });
  });

  /* ---------- 6) SpotlightCard: إضاءة تتبع المؤشر على البطاقات ---------- */
  safe(function () {
    if (!fine) return;
    var SP = '.my .card,.my .tool,main .glass-panel';
    var spot = document.createElement('div');
    spot.id = 'rb-spot'; spot.setAttribute('aria-hidden', 'true');
    document.body.appendChild(spot);
    var cur = null;
    function place() {
      if (!cur) return;
      var r = cur.getBoundingClientRect();
      spot.style.transform = 'translate(' + r.left + 'px,' + r.top + 'px)';
      spot.style.width = r.width + 'px'; spot.style.height = r.height + 'px';
      return r;
    }
    document.addEventListener('pointermove', function (e) {
      var t = e.target.closest ? e.target.closest(SP) : null;
      if (t && hero && t === hero) t = null;
      if (!t) { cur = null; spot.style.opacity = 0; return; }
      if (t !== cur) { cur = t; spot.style.borderRadius = getComputedStyle(t).borderRadius; spot.style.opacity = 1; }
      var r = place();
      spot.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      spot.style.setProperty('--my', (e.clientY - r.top) + 'px');
    }, { passive: true });
    addEventListener('scroll', function () { if (cur) place(); }, { passive: true });
    document.addEventListener('pointerout', function (e) { if (!e.relatedTarget) { cur = null; spot.style.opacity = 0; } });
  });

  /* ---------- 7) Magnet: أزرار الهيرو تنجذب للمؤشر ---------- */
  safe(function () {
    if (!fine) return;
    document.querySelectorAll('#hsb,#view-home .mt-6.flex button').forEach(function (b) {
      var qx = gsap.quickTo(b, 'x', { duration: 0.5, ease: 'power3.out' });
      var qy = gsap.quickTo(b, 'y', { duration: 0.5, ease: 'power3.out' });
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        qx((e.clientX - r.left - r.width / 2) * 0.25);
        qy((e.clientY - r.top - r.height / 2) * 0.25);
      });
      b.addEventListener('pointerleave', function () { qx(0); qy(0); });
    });
  });

  /* ---------- 8) ClickSpark: شرارات عند النقر ---------- */
  safe(function () {
    document.addEventListener('pointerdown', function (e) {
      if (e.button) return;
      for (var i = 0; i < 8; i++) {
        var s = document.createElement('i');
        s.className = 'rb-sk'; s.style.left = e.clientX + 'px'; s.style.top = e.clientY + 'px';
        document.body.appendChild(s);
        var a = (Math.PI * 2 * i) / 8;
        gsap.fromTo(s, { x: Math.cos(a) * 6, y: Math.sin(a) * 6, rotation: a * 180 / Math.PI + 90, scale: 1, opacity: 1 },
          { x: Math.cos(a) * 30, y: Math.sin(a) * 30, scale: 0.2, opacity: 0, duration: 0.55, ease: 'power2.out',
            onComplete: (function (n) { return function () { n.remove(); }; })(s) });
      }
    }, { passive: true });
  });

  /* ---------- 9) مؤشر مخصص (Cursor) ---------- */
  safe(function () {
    if (!fine) return;
    var ring = document.createElement('div');
    ring.id = 'rb-cursor'; ring.setAttribute('aria-hidden', 'true');
    document.body.appendChild(ring);
    gsap.set(ring, { xPercent: -50, yPercent: -50, opacity: 0 });
    var qx = gsap.quickTo(ring, 'x', { duration: 0.35, ease: 'power3.out' });
    var qy = gsap.quickTo(ring, 'y', { duration: 0.35, ease: 'power3.out' });
    var HOT = 'a,button,[onclick],summary,select,label,input[type=checkbox],input[type=radio]';
    document.addEventListener('pointermove', function (e) {
      qx(e.clientX); qy(e.clientY);
      var hot = !!(e.target.closest && e.target.closest(HOT));
      gsap.to(ring, { opacity: 1, scale: hot ? 1.9 : 1, duration: 0.25, overwrite: 'auto' });
      ring.classList.toggle('hot', hot);
    }, { passive: true });
    document.addEventListener('pointerout', function (e) { if (!e.relatedTarget) gsap.to(ring, { opacity: 0, duration: 0.2 }); });
    document.addEventListener('pointerdown', function () { gsap.to(ring, { scale: 0.7, duration: 0.15 }); });
    document.addEventListener('pointerup', function () { gsap.to(ring, { scale: ring.classList.contains('hot') ? 1.9 : 1, duration: 0.25 }); });
  });

  /* ---------- 10) شريط الأخبار: يتسارع مع سرعة التمرير ويتوقف عند المرور (ScrollVelocity) ---------- */
  safe(function () {
    var tk = document.querySelector('.ticker-move');
    if (!tk || !tk.getAnimations) return;
    var anim = null, rate = 1, target = 1, hovering = false;
    var wrap = tk.closest('.ticker-wrap') || tk;
    wrap.addEventListener('pointerenter', function () { hovering = true; });
    wrap.addEventListener('pointerleave', function () { hovering = false; });
    var lastY = scrollY;
    gsap.ticker.add(function () {
      if (!anim) { anim = tk.getAnimations()[0]; if (!anim) return; }
      var v = Math.abs(scrollY - lastY); lastY = scrollY;
      target = hovering ? 0 : 1 + Math.min(v * 0.35, 6);
      rate += (target - rate) * 0.12;
      anim.playbackRate = Math.max(rate, 0.0001);
    });
  });
})();
