/* tailwind-config */
tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        vetDark: '#070a13',
                        vetCard: '#0f172a',
                        vetCyan: '#06b6d4',
                        vetEmerald: '#10b981',
                        vetAccent: '#8b5cf6',
                        vetNeon: '#38bdf8'
                    },
                    fontFamily: {
                        sans: ['Cairo', 'system-ui', 'sans-serif']
                    }
                }
            }
        }
