/* 24-contact-photo */
/* صورة الدكتور بجانب عنوان «التواصل والخدمات» (تعيد استعمال صورة المؤسس دون تحميل إضافي) */
(function(){
  function a(){
    var f=document.querySelector('#view-creator img[alt="الدكتور محجوبي عبدالناصر"]');
    var h=document.querySelector('#contact .sectionHead');
    if(!f||!h||document.getElementById('ct-photo'))return;
    var i=document.createElement('img');
    i.id='ct-photo';i.src=f.src;i.alt='الدكتور محجوبي عبدالناصر';i.width=64;i.height=64;i.decoding='async';
    i.style.cssText='flex:none;width:64px;height:64px;border-radius:18px;object-fit:cover;border:2px solid rgba(16,185,129,.65);box-shadow:0 4px 12px rgba(0,0,0,.25)';
    h.style.display='flex';h.style.alignItems='center';h.style.justifyContent='flex-start';h.style.gap='12px';
    h.insertBefore(i,h.firstChild);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',a);else a();
})();
